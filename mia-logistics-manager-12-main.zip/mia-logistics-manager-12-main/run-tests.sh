#!/bin/bash
echo "🧪 Running tests for MIA Logistics Manager..."
npm test -- --coverage --watchAll=false
