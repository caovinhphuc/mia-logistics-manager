#!/bin/bash
echo "🚀 Starting MIA Logistics Manager in development mode..."
export NODE_ENV=development
export BROWSER=none
npm start
