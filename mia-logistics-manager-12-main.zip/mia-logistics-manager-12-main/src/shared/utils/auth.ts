// Utility function to check permissions
export const requirePermission = (resource: string, action: string) => {
  // For now, return true - implement actual permission logic later
  return true;
};
