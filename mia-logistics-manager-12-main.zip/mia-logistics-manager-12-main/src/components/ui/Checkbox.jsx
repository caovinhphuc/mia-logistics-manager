import Checkbox from '@mui/material/Checkbox';

export default Checkbox;
