#!/bin/bash
echo "🔧 Running linter and fixing issues..."
npm run lint:fix
npm run format
